package com.devsuperior.hrconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
